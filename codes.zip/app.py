from flask import Flask, request, jsonify
import pickle
import numpy as np
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
import pandas as pd
import mlflow
import os

app = Flask(__name__)

# Model yükleme
model_path = os.path.join('C:/Users/ABREBO/PycharmProjects/mlops_project/mlruns/0/your_key/artifacts/XGBoost_model/model.pkl')
model = pickle.load(open(model_path, 'rb'))
scaler = StandardScaler()

# Koşu ID'si (Run ID) belirleme
RUN_ID = "your_run_id"

# Gerçek değerler ve tahminler için listeler
true_values = []
predictions = []

# Flask rotaları
@app.route('/')
def home():
    return "Hello, this is the XGBoost prediction service!"

@app.route("/predict", methods=['POST'])
def predict():
    global true_values, predictions
    data = request.json
    features = ['CreditScore', 'Gender', 'Age', 'Tenure', 'Balance', 'NumOfProducts', 'HasCrCard', 'IsActiveMember', 'EstimatedSalary']

    try:
        # Veriyi uygun formata getirme
        input_data = [[data[feature] for feature in features]]
        df_input = pd.DataFrame(input_data, columns=features)

        # Kategorik verilerin kodlanması
        df_input['Gender'] = LabelEncoder().fit_transform(df_input['Gender'])

        # Verilerin ölçeklendirilmesi
        input_scaled = scaler.fit_transform(df_input)

        # Tahmin yap
        prediction = model.predict(input_scaled)
        result = prediction[0]

        # Gerçek değerleri elde etme
        if 'true_value' in data:
            true_value = data['true_value']
            true_values.append(true_value)
            predictions.append(result)

            # Performans metriklerini hesapla
            accuracy = accuracy_score(true_values, predictions)
            precision = precision_score(true_values, predictions, zero_division=0)
            recall = recall_score(true_values, predictions, zero_division=0)
            f1 = f1_score(true_values, predictions, zero_division=0)

            # Mevcut koşuyu başlat ve metrikleri güncelle
            with mlflow.start_run(run_id=RUN_ID):
                mlflow.log_metric("accuracy", accuracy)
                mlflow.log_metric("precision", precision)
                mlflow.log_metric("recall", recall)
                mlflow.log_metric("f1_score", f1)
        else:
            # `true_value` sağlanmamışsa bir uyarı döndür
            return jsonify({'error': 'true_value is missing from the request'}), 400

        return jsonify({'prediction': int(result)})

    except KeyError as e:
        return jsonify({'error': f'Missing key in the request data: {e}'}), 400

    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(port=5001, debug=True)
