import pandas as pd
import mlflow
import matplotlib.pyplot as plt

# MLflow'dan metrikleri çekme
client = mlflow.tracking.MlflowClient()
runs = client.search_runs(experiment_ids=["0"], filter_string="attributes.status = 'FINISHED'")

# Performans metriklerini toplama
accuracy_list = []
precision_list = []
recall_list = []
f1_list = []

for run in runs:
    metrics = run.data.metrics
    accuracy_list.append(metrics["accuracy"])
    precision_list.append(metrics["precision"])
    recall_list.append(metrics["recall"])
    f1_list.append(metrics["f1_score"])

# Zaman içinde performans değişikliklerini görselleştirme
plt.figure(figsize=(10, 6))
plt.plot(accuracy_list, label="Accuracy")
plt.plot(precision_list, label="Precision")
plt.plot(recall_list, label="Recall")
plt.plot(f1_list, label="F1 Score")
plt.xlabel("Run")
plt.ylabel("Metric Value")
plt.title("Model Performance Over Time")
plt.legend()
plt.show()
