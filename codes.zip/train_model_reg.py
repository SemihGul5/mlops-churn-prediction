import pandas as pd
import xgboost as xgb
import mlflow.sklearn
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error
# Verileri Yükleme
def load_data(file_path):
    return pd.read_csv(file_path)

if __name__ == "__main__":
    X_train = load_data('X_train.csv')
    X_test = load_data('X_test.csv')
    y_train = load_data('y_train.csv').values.ravel()
    y_test = load_data('y_test.csv').values.ravel()

    mlflow.set_tracking_uri("http://localhost:5000")
    mlflow.set_experiment("Default")

    # Modeli oluşturma
    model = xgb.XGBRegressor(learning_rate=0.1, max_depth=5, n_estimators=300)
    model.fit(X_train, y_train)

    # Tahminler
    y_pred = model.predict(X_test)

    # Değerlendirme Metrikleri
    r2 = r2_score(y_test, y_pred)
    mae = mean_absolute_error(y_test, y_pred)
    mse = mean_squared_error(y_test, y_pred)

    # Metrikleri Kaydetme
    with mlflow.start_run():
        mlflow.log_param("learning_rate", 0.1)
        mlflow.log_param("max_depth", 5)
        mlflow.log_param("n_estimators", 300)
        mlflow.log_metric("r2", r2)
        mlflow.log_metric("mae", mae)
        mlflow.log_metric("mse", mse)

        # Modeli Kaydetme ve İsimlendirme
        model_name = "XGBoost_Regressor_model"
        mlflow.sklearn.log_model(model, model_name)
