import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
from imblearn.over_sampling import SMOTE

# Veri Alma
def load_data(file_path):
    return pd.read_csv(file_path)

# Veri Ön İşleme
def preprocess_data(df):
    # Sütunların ayrıştırılması
    X = df.drop(['RowNumber','Geography', 'CustomerId', 'Surname', 'Exited'], axis=1)
    y = df['Exited']

    # Kategorik verilerin kodlanması
    label_encoder = LabelEncoder()
    X['Gender'] = label_encoder.fit_transform(X['Gender'])

    # Verilerin ölçeklendirilmesi
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    # SMOTE uygulaması
    smote = SMOTE(random_state=42)
    X_resampled, y_resampled = smote.fit_resample(X_scaled, y)

    return train_test_split(X_resampled, y_resampled, test_size=0.15, random_state=42, stratify=y_resampled)

if __name__ == "__main__":
    df = load_data('C:/Users/ABREBO/Desktop/Churn_Modelling.csv')
    X_train, X_test, y_train, y_test = preprocess_data(df)
    # Eğitim ve test verilerini kaydetme
    pd.DataFrame(X_train).to_csv('X_train.csv', index=False)
    pd.DataFrame(X_test).to_csv('X_test.csv', index=False)
    pd.DataFrame(y_train).to_csv('y_train.csv', index=False)
    pd.DataFrame(y_test).to_csv('y_test.csv', index=False)
