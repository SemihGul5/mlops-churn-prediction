import pandas as pd
import xgboost as xgb
from sklearn.model_selection import GridSearchCV
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score,confusion_matrix
import mlflow.sklearn

# Verileri Yükleme
def load_data(file_path):
    return pd.read_csv(file_path)
if __name__ == "__main__":
    X_train = load_data('X_train.csv')
    X_test = load_data('X_test.csv')
    y_train = load_data('y_train.csv').values.ravel()
    y_test = load_data('y_test.csv').values.ravel()

    mlflow.set_tracking_uri("http://localhost:5000")
    mlflow.set_experiment("Default")

    # Grid Search ile en iyi parametreleri bulma
    param_grid = {
        'max_depth': [3, 4, 5],
        'learning_rate': [0.1, 0.01, 0.001],
        'n_estimators': [100, 200, 300]
    }
    grid_search = GridSearchCV(xgb.XGBClassifier(), param_grid, cv=5)
    grid_search.fit(X_train, y_train)

    best_params = grid_search.best_params_

    with mlflow.start_run():
        # En iyi parametreleri kaydetme
        for param_name, param_value in best_params.items():
            mlflow.log_param(param_name, param_value)

        # En iyi parametrelerle modeli eğitme
        model = xgb.XGBClassifier(**best_params)
        model.fit(X_train, y_train)

        # Tahminler
        y_pred = model.predict(X_test)

        # Değerlendirme Metrikleri
        accuracy = accuracy_score(y_test, y_pred)
        precision = precision_score(y_test, y_pred)
        recall = recall_score(y_test, y_pred)
        f1 = f1_score(y_test, y_pred)

        # Metrikleri Kaydetme
        mlflow.log_metric("accuracy", accuracy)
        mlflow.log_metric("precision", precision)
        mlflow.log_metric("recall", recall)
        mlflow.log_metric("f1_score", f1)

        # Karar matrisi oluşturma
        confusion = confusion_matrix(y_test, y_pred)
        tn, fp, fn, tp = confusion.ravel()

        # Karar matrisini MLflow'a kaydetme
        mlflow.log_metric("True Negatives", tn)
        mlflow.log_metric("False Positives", fp)
        mlflow.log_metric("False Negatives", fn)
        mlflow.log_metric("True Positives", tp)

        # Modeli Kaydetme ve İsimlendirme
        model_name = "XGBoost_model"
        mlflow.sklearn.log_model(model, model_name)
