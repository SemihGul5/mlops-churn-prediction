import pandas as pd
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
import mlflow
import mlflow.sklearn


# Verileri Yükleme
def load_data(file_path):
    return pd.read_csv(file_path)


if __name__ == "__main__":
    X_train = load_data('X_train.csv')
    X_test = load_data('X_test.csv')
    y_train = load_data('y_train.csv').values.ravel()
    y_test = load_data('y_test.csv').values.ravel()

    mlflow.set_tracking_uri("http://localhost:5000")
    mlflow.set_experiment("Customer_Churn_Experiment_knn")

    for n_neighbors in range(1, 11):  # KNN'de kullanılacak komşu sayısını 1'den 10'a
        with mlflow.start_run():
            # Modeli Eğitme
            model = KNeighborsClassifier(n_neighbors=n_neighbors)
            model.fit(X_train, y_train)

            # Tahminler
            y_pred = model.predict(X_test)

            # Değerlendirme Metrikleri
            accuracy = accuracy_score(y_test, y_pred)
            precision = precision_score(y_test, y_pred)
            recall = recall_score(y_test, y_pred)
            f1 = f1_score(y_test, y_pred)

            # Metrikleri Kaydetme
            mlflow.log_metric("accuracy", accuracy)
            mlflow.log_metric("precision", precision)
            mlflow.log_metric("recall", recall)
            mlflow.log_metric("f1_score", f1)

            # Modeli Kaydetme ve İsimlendirme
            model_name = f"knn_model_n={n_neighbors}"
            mlflow.sklearn.log_model(model, model_name)
