import pandas as pd
from sklearn.model_selection import RandomizedSearchCV
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
import mlflow
import mlflow.sklearn

# Verileri Yükleme
def load_data(file_path):
    return pd.read_csv(file_path)

if __name__ == "__main__":
    X_train = load_data('X_train.csv')
    X_test = load_data('X_test.csv')
    y_train = load_data('y_train.csv').values.ravel()
    y_test = load_data('y_test.csv').values.ravel()

    mlflow.set_tracking_uri("http://localhost:5000")
    mlflow.set_experiment("Customer_Churn_Experiment")

    # Random Forest için hiperparametre aralıklarını tanımla
    param_grid = {
        'n_estimators': [50, 100, 150],
        'max_depth': [None, 10, 20],
        'min_samples_split': [2, 5, 10],
        'min_samples_leaf': [1, 2, 4]
    }

    # Randomized Search CV kullanarak en iyi parametreleri bulma
    rf = RandomForestClassifier(random_state=42)
    search = RandomizedSearchCV(rf, param_grid, scoring='accuracy', cv=5, n_iter=10, random_state=42)
    search.fit(X_train, y_train)

    best_params = search.best_params_

    with mlflow.start_run():
        # En iyi parametrelerle modeli eğitme
        model = RandomForestClassifier(**best_params, random_state=42)
        model.fit(X_train, y_train)

        # Tahminler
        y_pred = model.predict(X_test)

        # Değerlendirme Metrikleri
        accuracy = accuracy_score(y_test, y_pred)
        precision = precision_score(y_test, y_pred)
        recall = recall_score(y_test, y_pred)
        f1 = f1_score(y_test, y_pred)

        # Hiperparametreleri Metrikler olarak Kaydetme
        for param, value in best_params.items():
            mlflow.log_param(param, value)

        # Metrikleri Kaydetme
        mlflow.log_metric("accuracy", accuracy)
        mlflow.log_metric("precision", precision)
        mlflow.log_metric("recall", recall)
        mlflow.log_metric("f1_score", f1)

        # Modeli Kaydetme ve İsimlendirme
        model_name = "random_forest_model"
        mlflow.sklearn.log_model(model, model_name)
